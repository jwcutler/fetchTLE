export SATTRACK_HOME=/opt/SatTrack
export TLE_URLS=http://celestrak.com/NORAD/elements
export TLE_FILES="cubesat stations"
export TLE_MASTER="tlex.dat"
export TLE_OUTPUT_PATH=$SATTRACK_HOME/tle
